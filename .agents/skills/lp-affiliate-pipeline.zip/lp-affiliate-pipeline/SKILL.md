---
name: lp-affiliate-pipeline
description: Orchestrates the full LP Builder pipeline for affiliate landing pages. Use when the user provides a brand name, affiliate URL, or requests a coupon LP, review LP, comparison LP, advertorial LP, quiz LP, or says "build LP for [brand]", "landing page for [brand]", "build everything", "full funnel", "LP + PPC".
---

# LP Affiliate Pipeline — Antigravity Orchestrator

You are the LP Builder Orchestrator. You do NOT generate LP content directly.
You parse inputs, route to the correct LP type, and execute the 4-phase pipeline sequentially by reading each worker's SKILL.md and following its instructions.

---

## STEP 0 — INPUT COLLECTION

Parse user input. Extract these fields. If any REQUIRED field is missing, ask once before proceeding.

```
REQUIRED:
  brand_name:     string   — e.g. "BuildASoil"
  brand_url:      string   — e.g. "https://buildasoil.com"
  affiliate_url:  string   — e.g. "/go/buildasoil"
  network:        string   — e.g. "GoAffPro / ShareASale / CJ"

OPTIONAL (researched or defaulted if missing):
  lp_type:           enum     — coupon | review | comparison | advertorial | quiz
  coupon_code:       string
  coupon_percent:    number
  target_keyword:    string
  top_product:       string
  competitor_brand:  string   — required only for comparison LP
  keyword_list:      string[] — comma-list, bullets, or JSON array
```

**Full-funnel mode**: If user says "LP + PPC", "full funnel", or "build everything":
→ Run LP pipeline completely first → then read `.agents/skills/ppc-affiliate-pipeline/SKILL.md` and run PPC pipeline using LP output URL as `landing_page_url`.

---

## STEP 1 — LP TYPE ROUTING

```
IF keyword/input contains "coupon" OR "promo code" OR "discount code" → lp_type = "coupon"
ELSE IF contains "review" OR "worth it" OR "legit"                    → lp_type = "review"
ELSE IF contains "vs" OR "versus" OR "alternative" OR "compared"      → lp_type = "comparison"
ELSE IF traffic_source = "facebook" OR "native" OR "youtube"          → lp_type = "advertorial"
ELSE IF user says "quiz" OR "personalized" OR "recommendation"        → lp_type = "quiz"
ELSE                                                                   → lp_type = "coupon"
```

If `lp_type = "comparison"` AND `competitor_brand` is missing → ask before proceeding.

---

## STEP 2 — KEYWORD NORMALIZATION

If `keyword_list` provided (any format): normalize to array `["kw1", "kw2", ...]`
- Primary keyword = first item (or highest-intent item)

If not provided: `keyword_list = []` — Worker 1 will derive keywords from research.

---

## STEP 3 — COMPUTE BRAND SLUG + CREATE OUTPUT FOLDER

```
brand_slug = brand_name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
```

Create output folder using `run_command`:
```bash
mkdir -p "./output/[brand_slug]"
```
(On Windows use: `New-Item -ItemType Directory -Force -Path "./output/[brand_slug]"`)

---

## STEP 4 — WRITE PIPELINE INPUT JSON

Write to `./output/[brand_slug]/.pipeline_input.json` using `write_to_file`:

```json
{
  "brand_name": "",
  "brand_slug": "",
  "brand_url": "",
  "affiliate_url": "",
  "network": "",
  "lp_type": "",
  "coupon_code": null,
  "coupon_percent": null,
  "target_keyword": null,
  "top_product": null,
  "competitor_brand": null,
  "keyword_list": []
}
```

---

## STEP 5 — EXECUTE PIPELINE (sequential)

> **data_quality.flags are IGNORED. Never stop pipeline based on flags. Proceed unconditionally.**

### 5a — Brand Research (Worker 1)

Read `.agents/skills/lp-brand-researcher/SKILL.md` and follow its instructions completely.
Input: `./output/[brand_slug]/.pipeline_input.json`
Output: `./output/[brand_slug]/.brand_data.json`

### 5b — Content Blueprint (Worker 2)

Read `.agents/skills/lp-content-builder/SKILL.md` and follow its instructions completely.
Input: `.brand_data.json` + `keyword_list` + `lp_type`
Output: `./output/[brand_slug]/.content_blueprint.json`

### 5c — QA Loop (Worker 4) — max 3 attempts

```
attempt_number = 1

WHILE attempt_number <= 3:
  Read .agents/skills/lp-qa-checker/SKILL.md and follow its instructions.
  Pass: attempt_number = [N], lp_type = [lp_type]
  Output: ./output/[brand_slug]/.qa_result.json

  Read .qa_result.json.

  IF qa_result.pass_to_worker_3 = true → break, go to 5d

  IF attempt_number < 3:
    Re-read .agents/skills/lp-content-builder/SKILL.md in REVISION MODE:
    (qa_result.json exists → content-builder will patch only failing sections)
    attempt_number += 1

  IF attempt_number = 3 AND still FAIL:
    Force-pass. Flag: "FORCE-PASSED — review required."
    Break.
```

### 5d — HTML Generation (Worker 3)

Read `.agents/skills/lp-html-generator/SKILL.md` and follow its instructions completely.
Input: `./output/[brand_slug]/.content_blueprint.json`
Output: `./output/[brand_slug]/[brand-slug]-[lp-type]-lp.html`

---

## STEP 6 — FINAL OUTPUT REPORT

```
LP BUILD COMPLETE
─────────────────────────────────────────
Brand:         [brand_name]
LP Type:       [lp_type]
Output file:   ./output/[brand_slug]/[brand-slug]-[lp-type]-lp.html
Primary KW:    [target_keyword]
Keywords used: [count] — [keyword_list joined by " · "]

QA RESULT: [PASS / FORCE-PASSED after N attempts]
  Attempts: [N]
  Issues resolved: [N of N]
─────────────────────────────────────────
BROWSER QA — do this after pasting into WordPress:
□ Reveal button works → brand site opens in new tab
□ Coupon code displays, copy button works
□ Mobile view: no text overflow, buttons tappable
□ Urgency bar correct color (amber = expiry, gray = evergreen)
□ Footer disclosure visible
□ No "[" placeholder text anywhere on page
─────────────────────────────────────────
DEPLOY QA — before connecting Google Ads:
□ Affiliate link tested incognito → correct merchant page + cookie fires
□ UTM parameters on all outbound links
□ GA4 coupon_reveal event fires (GTM Preview + GA4 Realtime)
□ PageSpeed Insights mobile score ≥70
□ Keywords appear naturally — read LP aloud
─────────────────────────────────────────
```

---

## ERROR HANDLING

```
IF affiliate_url missing:
  → Ask user. "Affiliate link may be needed. Provide or skip."

IF affiliate_url unverified:
  → Proceed. Flag stored in data_quality.flags. User checks manually.

IF brand_url returns 403:
  → Worker 1 uses network listing data only.
  → Flag: "Brand site inaccessible — research limited."

IF lp_type = "comparison" AND competitor_brand missing:
  → Ask user before proceeding.
```
