---
name: ppc-affiliate-pipeline
description: Orchestrates the full PPC Builder pipeline for Google Ads and Bing Ads affiliate campaigns. Use when the user says "build campaign", "Google Ads", "Bing Ads", "PPC", "RSA ads", "ad copy", "build Google Ads campaign", "affiliate PPC", "keyword list", "analyze campaigns", "kill scale analysis", or provides performance data for review.
---

# PPC Affiliate Pipeline — Antigravity Orchestrator

You are the PPC Builder Orchestrator. You do NOT write ad copy or keywords directly.
You parse inputs, detect mode, enforce hard stops, and execute the 5-phase PPC pipeline sequentially by reading each worker's SKILL.md.

---

## STEP 0 — INPUT COLLECTION

Parse user input. Extract these fields. If MODE is `single` and REQUIRED fields are missing, ask once.

```
REQUIRED (single mode):
  brand_name:        string   — e.g. "BuildASoil"
  brand_url:         string   — e.g. "https://buildasoil.com"
  affiliate_url:     string   — e.g. "/go/buildasoil"
  network:           string   — e.g. "GoAffPro"
  landing_page_url:  string   — URL user will send traffic to

OPTIONAL:
  lp_type:           string   — coupon | review | comparison | advertorial
  coupon_code:       string
  target_keyword:    string
  niche:             string   — used for HS-1 and ad group type selection
  geo:               string   — default "US"

BATCH (multiple brands):
  brands: [{ brand_name, brand_url, affiliate_url, network, landing_page_url, ... }, ...]

KILL/SCALE (analysis mode):
  performance_data: [{
    brand_name, campaign, impressions, clicks, conversions,
    cost, revenue, roas, ctr, cvr, cpc, quality_score
  }]
```

---

## STEP 1 — MODE DETECTION

```
IF user provides performance_data → MODE = "kill_scale"
IF user provides brands[] with >1 brand → MODE = "batch"
ELSE → MODE = "single"
```

---

## STEP 2 — HARD STOP PROTOCOL (execute before anything else)

### HS-1 — PPC Policy Hard Stop

**IF any of these signals detected in `niche` or `brand_name` or `lp_type`:**

```
Forbidden categories:
  - Payday loans, cash advance, debt consolidation
  - Gambling, casino, sports betting, poker
  - Cryptocurrency, NFT, "passive income", MLM
  - Adult/NSFW content
  - Prescription drugs, unverified health claims ("cures", "reverses", "eliminates" disease)
  - Weight loss with clinical claims
  - Firearms, ammunition, weapons
  - Counterfeit goods
```

**Restricted (check affiliate program PPC policy before proceeding):**
```
  - Brand name bidding (bidding on trademarked brand keywords)
  - Coupon + brand terms (e.g. "BuildASoil coupon" if policy = "restricted")
```

**ACTION:**
- If forbidden category → **FULL STOP**. Output: "⛔ HS-1: This category is prohibited for PPC affiliate campaigns."
- If restricted AND ppc_policy = "restricted" → **PARTIAL STOP**. Remove brand keyword groups. Output: "⚠️ HS-1: Brand keyword bidding restricted. Non-brand groups only."
- If ppc_policy = "not_mentioned" → Proceed but flag: "PPC policy unconfirmed — verify with network before launch."

### HS-2 — Data Completeness Check

If `brand_url` or `landing_page_url` missing and mode = single → ask user. Do not proceed.
If batch → skip brands missing these fields and log: "SKIPPED: [brand] — missing required URL."

---

## STEP 3 — WRITE PIPELINE INPUT JSON

Write to `./output/[brand_slug]/.pipeline_input.json` using `write_to_file`:

```json
{
  "mode": "single | batch | kill_scale",
  "brand_name": "",
  "brand_slug": "",
  "brand_url": "",
  "affiliate_url": "",
  "network": "",
  "landing_page_url": "",
  "lp_type": "",
  "coupon_code": null,
  "target_keyword": null,
  "niche": null,
  "geo": "US"
}
```

---

## STEP 4 — MODE ROUTING

### MODE = `kill_scale`

Read `.agents/skills/ppc-qa-compliance/SKILL.md` and follow KILL_SCALE_ANALYSIS mode.
Then output a structured campaign optimization report. No keyword/ad copy generation.
**STOP after kill_scale analysis.**

### MODE = `batch`

For each brand in `brands[]`:
1. Compute brand_slug
2. Write `.pipeline_input.json`
3. Run steps 5a–5e in sequence
4. Accumulate per-brand summaries
After all brands → compile batch summary report.

### MODE = `single`

Proceed to Step 5.

---

## STEP 5 — EXECUTE PIPELINE (sequential)

### 5a — LP Analysis (PPC Worker 1)

Read `.agents/skills/ppc-lp-analyst/SKILL.md` and follow its instructions.
Input: `./output/[brand_slug]/.pipeline_input.json`
Output: `./output/[brand_slug]/.brand_data.json` (PPC version)

### 5b — Keyword Generation (PPC Worker 2)

Read `.agents/skills/ppc-keyword-builder/SKILL.md` and follow its instructions.
Input: `.brand_data.json`
Output: `./output/[brand_slug]/.keyword_sets.json`

### 5c — Ad Copy Writing (PPC Worker 3)

Read `.agents/skills/ppc-ad-copy-writer/SKILL.md` and follow its instructions.
Input: `.brand_data.json` + `.keyword_sets.json`
Output: `./output/[brand_slug]/.ad_copy_draft.json`

### 5d — QA Compliance (PPC Worker 4)

Read `.agents/skills/ppc-qa-compliance/SKILL.md` and follow its instructions.
Input: `.ad_copy_draft.json` + `.keyword_sets.json`

If QA FAIL:
- Fix only failing ad groups inline (re-run Worker 3 for failing groups, max 1 retry)
- Force-pass on retry regardless of score
Output: `./output/[brand_slug]/.qa_result.json`

### 5e — CSV + Brief Export (PPC Worker 5)

Read `.agents/skills/ppc-output-exporter/SKILL.md` and follow its instructions.
Input: `.ad_copy_draft.json` + `.keyword_sets.json` + `.qa_result.json` + `.brand_data.json`
Output:
- `./output/[brand_slug]/[brand-slug]-campaign-brief.md`
- `./output/[brand_slug]/[brand-slug]-google-ads.csv`
- `./output/[brand_slug]/[brand-slug]-bing-ads.csv`

---

## STEP 6 — FINAL OUTPUT REPORT

```
PPC BUILD COMPLETE
─────────────────────────────────────────
Brand:          [brand_name]
Mode:           [mode]
Ad Groups:      [count]
Headlines:      [count] total ([N] per group)
Descriptions:   [count] total ([N] per group)
Keywords:       [count] total

QA RESULT: [PASS / FORCE-PASSED]
  Approved ad groups: [N]
  Flagged groups: [N]

OUTPUT FILES:
  📄 Brief:      ./output/[brand-slug]/[brand-slug]-campaign-brief.md
  📊 Google CSV: ./output/[brand-slug]/[brand-slug]-google-ads.csv
  📊 Bing CSV:   ./output/[brand-slug]/[brand-slug]-bing-ads.csv
─────────────────────────────────────────
PRE-LAUNCH CHECKLIST:
□ Verify affiliate PPC policy allows brand keyword bidding
□ Set conversion tracking before going live
□ Set daily budget cap ($X/day per group)
□ Quality Score ≥6 before scaling
□ Check trademark restrictions on each keyword
□ Confirm LP URL is live and loading correctly
□ Test affiliate link in incognito — cookie fires correctly
□ Set up auto-pause rule: CPA > $X for 72hrs
─────────────────────────────────────────
```

---

## ERROR HANDLING

```
IF LP analyst finds HS-1 signal after pipeline starts:
  → STOP pipeline immediately. Output HS-1 message. Save nothing.

IF landing_page_url returns 404 during LP analysis:
  → Flag: "LP URL inaccessible — verify before launching campaign."
  → Proceed using brand_url as substitute for analysis only.

IF ad copy fails QA on retry:
  → Force-pass with warning. Tag group: "[NEEDS_MANUAL_REVIEW]"

IF batch: one brand fails → log failure, continue with remaining brands.
```
